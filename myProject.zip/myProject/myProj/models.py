from djongo import models

# Create your models here.

class Student(models.Model):
	student_id=models.CharField(primary_key=True , max_length=10,default="")
	student_name = models.CharField(max_length=100,default="")
	student_dob = models.DateTimeField
	student_emailid=models.EmailField
	student_phonenumber=models.IntegerField
	student_year=models.IntegerField
	student_branch=models.CharField(max_length=2,default="")
	student_div=models.CharField(max_length=1,default="")

class Faculty(models.Model):
	faculty_name=models.CharField(max_length=25,default="")
	faculty_init=models.CharField(max_length=4,default="")
	faculty_email=models.EmailField
	faculty_phonenumber=models.IntegerField
	faculty_branch=models.CharField(max_length=2,default="")

class Classes(models.Model):
	branch=models.CharField(max_length=2,default="")
	division=models.CharField(max_length=1,default="")
	class Meta:
		unique_together = (('branch', 'division'),)

#time table - class year div faculty sub time roomno 
