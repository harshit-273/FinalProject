from django.apps import AppConfig


class TimetableConfig(AppConfig):
    name = 'TimeTable'
